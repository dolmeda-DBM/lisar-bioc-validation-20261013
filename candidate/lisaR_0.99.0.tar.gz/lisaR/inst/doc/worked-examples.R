## ----riaz-on, eval=FALSE------------------------------------------------------
# library(lisaR)
# 
# # Use a short, writable path. Change C:/lisa if needed.
# root <- if (.Platform$OS.type == "windows") "C:/lisa" else "~/lisa"
# root <- path.expand(root)
# dir.create(root, recursive = TRUE, showWarnings = FALSE)
# 
# # Prepare the human gene-set membership resource once.
# prepare_lisa_msigdb_resource(accept_terms = TRUE)
# 
# # Download the prepared Riaz data to a new directory.
# riaz <- install_lisa_example_bundle(
#   "riaz-gse91061",
#   destination = file.path(root, "riaz-data")
# )
# 
# # Analyse ON only: CR/PR responders versus PD during treatment.
# result <- run_lisa(
#   de = list(responders_vs_pd_on = file.path(
#     riaz$bundle, "outputs", "lisa_inputs", "responders_vs_pd_on.tsv"
#   )),
#   output_dir = file.path(root, "riaz-on"),
#   species = "Homo sapiens",
#   method = "DESeq2",
#   positive_direction =
#     "Higher in CR/PR responders than in PD during treatment",
#   mode = "standard"
# )
# 
# stopifnot(identical(result$gate, "PASS"))
# browseURL(result$report_index)

## ----obtain-riaz-bundle, eval=FALSE-------------------------------------------
# library(lisaR)
# root <- if (.Platform$OS.type == "windows") "D:/lisa" else "~/lisa"
# root <- path.expand(root)
# dir.create(file.path(root, "bundles"), recursive = TRUE, showWarnings = FALSE)
# 
# bundle <- install_lisa_example_bundle(
#   "riaz-gse91061",
#   destination = file.path(root, "bundles", "riaz")
# )
# bundle$next_command

## ----prepare-riaz-project, eval=FALSE-----------------------------------------
# project <- normalizePath(file.path(root, "riaz"),
#                          winslash = "/", mustWork = FALSE)
# Sys.setenv(
#   LISAR_RIAZ_PREPARED_BUNDLE = bundle$bundle,
#   LISAR_RIAZ_PROJECT_DIR = project
# )
# example_dir <- system.file("examples", "riaz-gse91061", package = "lisaR")
# rscript <- file.path(R.home("bin"), "Rscript")
# prepare_script <- file.path(example_dir, "scripts", "11_prepare_prepared_project.R")
# stopifnot(system2(rscript, c("--vanilla", shQuote(prepare_script))) == 0L)

## ----check-riaz-study, eval=FALSE---------------------------------------------
# config <- file.path(project, "study.yml")
# study <- yaml::read_yaml(config)
# print(data.frame(
#   analysis = vapply(study$single_de, `[[`, character(1), "analysis_id"),
#   comparison = vapply(study$single_de, `[[`, character(1), "comparison"),
#   positive_direction = vapply(study$single_de, `[[`, character(1),
#                               "positive_direction")
# ))
# print(study$collections)
# print(study$report)
# 
# validation <- validate_lisa_config(config, check_files = TRUE)
# stopifnot(validation$execution_ready)
# output_plan <- plan_lisa_outputs(config)
# print(output_plan$summary)

## ----run-riaz-standard, eval=FALSE--------------------------------------------
# run_script <- file.path(example_dir, "scripts", "09_run_lisa_example.R")
# stopifnot(system2(rscript, c("--vanilla", shQuote(run_script))) == 0L)
# browseURL(file.path(project, "out", "report_index.html"))

## ----build-selected-riaz-full, eval=FALSE-------------------------------------
# source_dir <- file.path(project, "out")
# output_dir <- file.path(project, "extra")
# stopifnot(dir.exists(source_dir), !file.exists(output_dir))
# script <- system.file("scripts", "build_selected_LISA_report.R", package = "lisaR")
# 
# status <- system2(file.path(R.home("bin"), "Rscript"), c(
#   "--vanilla", shQuote(script),
#   "--source-dir", shQuote(source_dir),
#   "--output-dir", shQuote(output_dir),
#   "--analyses", "responders_vs_pd_pre,responders_vs_pd_on",
#   "--contrasts", "response_separation_by_time",
#   "--complete-missing", "true",
#   "--title", shQuote("Response-group separation during and before nivolumab")
# ))
# stopifnot(status == 0L)
# browseURL(file.path(output_dir, "report_index.html"))

## ----locate-riaz-reconstruction, eval=TRUE------------------------------------
example_dir <- system.file("examples", "riaz-gse91061", package = "lisaR")
list.files(file.path(example_dir, "scripts"), pattern = "^0[0-5]_", full.names = TRUE)

## ----obtain-cptac-bundle, eval=FALSE------------------------------------------
# library(lisaR)
# root <- if (.Platform$OS.type == "windows") "D:/lisa" else "~/lisa"
# root <- path.expand(root)
# dir.create(file.path(root, "bundles"), recursive = TRUE, showWarnings = FALSE)
# 
# bundle <- install_lisa_example_bundle(
#   "cptac-ccrcc",
#   destination = file.path(root, "bundles", "cptac")
# )
# bundle$next_command

## ----prepare-cptac-project, eval=FALSE----------------------------------------
# project <- normalizePath(file.path(root, "cptac"),
#                          winslash = "/", mustWork = FALSE)
# Sys.setenv(
#   LISAR_CPTAC_CCRCC_BUNDLE = bundle$bundle,
#   LISAR_CPTAC_CCRCC_PROJECT_DIR = project,
#   LISAR_CPTAC_CCRCC_PREPARE_ONLY = "1"
# )
# prepare_script <- system.file("examples", "cptac-ccrcc",
#   "prepare_and_run_cptac_ccrcc.R", package = "lisaR")
# status <- system2(file.path(R.home("bin"), "Rscript"),
#                   c("--vanilla", shQuote(prepare_script)))
# Sys.unsetenv("LISAR_CPTAC_CCRCC_PREPARE_ONLY")
# stopifnot(status == 0L)

## ----inspect-cptac-example, eval=FALSE----------------------------------------
# config <- file.path(project, "study.yml")
# study <- yaml::read_yaml(config)
# print(study$pipeline)
# print(data.frame(
#   analysis = study$single_de[[1]]$analysis_id,
#   comparison = study$single_de[[1]]$comparison,
#   positive_direction = study$single_de[[1]]$positive_direction,
#   rank_column = study$single_de[[1]]$rank_col
# ))
# validation <- validate_lisa_config(config, check_files = TRUE)
# stopifnot(validation$execution_ready)
# output_plan <- plan_lisa_outputs(config)
# print(output_plan$summary)

## ----run-cptac-example, eval=FALSE--------------------------------------------
# result <- run_lisa(config)
# check <- verify_lisa_run(result$output_dir)
# stopifnot(identical(result$gate, "PASS"), identical(check$gate, "PASS"))
# print(result$output_dir)
# browseURL(file.path(result$output_dir, "report_index.html"))

## ----inspect-saved-example-values, eval=TRUE----------------------------------
read_saved_example <- function(name) utils::read.delim(
  file.path("figures", name), sep = "\t", check.names = FALSE
)
riaz_saved <- read_saved_example("riaz-category_source.tsv")
cptac_saved <- read_saved_example("cptac-category_source.tsv")
stopifnot(nrow(riaz_saved) > 0L, nrow(cptac_saved) > 0L)
print(utils::head(riaz_saved))
print(utils::head(cptac_saved))
data.frame(example = c("Riaz", "CPTAC"),
           saved_rows = c(nrow(riaz_saved), nrow(cptac_saved)),
           saved_columns = c(ncol(riaz_saved), ncol(cptac_saved)))

## ----documentation-session-info, eval=TRUE------------------------------------
sessionInfo()

