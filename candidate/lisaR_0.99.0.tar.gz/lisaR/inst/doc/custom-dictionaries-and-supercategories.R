## ----create-project, eval=TRUE------------------------------------------------
library(lisaR)

project <- lisa_init_project(tempfile("lisa-custom-"))
resource_dir <- file.path(project, "custom-resources")
stopifnot(!dir.exists(resource_dir))
dir.create(resource_dir)

## ----construct-memberships, eval=TRUE-----------------------------------------
sample_root <- system.file("extdata", "quick-start", package = "lisaR")
read_sample <- function(name) utils::read.delim(
  file.path(sample_root, name), sep = "\t", quote = "", comment.char = "",
  check.names = FALSE, stringsAsFactors = FALSE,
  colClasses = "character", na.strings = character()
)

term2gene <- read_sample("example_term2gene_v2_0.tsv")
sample_dictionary <- read_sample("lisa_dictionary_quickstart_v1_1.tsv")
gene_sets <- unique(sample_dictionary[, c(
  "universe", "gene_set_id", "gene_set_name"
)])

print(utils::head(term2gene, 12))
print(gene_sets)

## ----construct-classification, eval=TRUE--------------------------------------
classification <- data.frame(
  token = c("_SIGNAL_", "_STRESS_", "_PROLIF_", "_MATRIX_"),
  category_id = c(
    "LAB_SIGNAL", "LAB_STRESS", "LAB_PROLIFERATION", "LAB_MATRIX"
  ),
  category_display_name = c(
    "Example of signal response", "Example of stress response",
    "Example of proliferation", "Example of matrix remodelling"
  ),
  stringsAsFactors = FALSE
)

category_index <- vapply(gene_sets$gene_set_id, function(gene_set_id) {
  hits <- vapply(
    classification$token, grepl, logical(1),
    x = gene_set_id, fixed = TRUE
  )
  stopifnot(sum(hits) == 1L)
  which(hits)
}, integer(1))

dictionary <- data.frame(
  universe = gene_sets$universe,
  gene_set_id = gene_sets$gene_set_id,
  gene_set_name = gene_sets$gene_set_name,
  source_id = rep("CUSTOM_SAMPLE40", nrow(gene_sets)),
  category_id = classification$category_id[category_index],
  category_display_name =
    classification$category_display_name[category_index],
  tier = rep("custom", nrow(gene_sets)),
  stringsAsFactors = FALSE
)

category_map <- data.frame(
  category_id = classification$category_id,
  display_name = classification$category_display_name,
  macrogroup_id = c(
    "LAB_RESPONSES", "LAB_RESPONSES",
    "LAB_GROWTH_STRUCTURE", "LAB_GROWTH_STRUCTURE"
  ),
  macrogroup_name = c(
    "Example response programmes", "Example response programmes",
    "Example growth and structure", "Example growth and structure"
  ),
  macrogroup_order = c(1L, 1L, 2L, 2L),
  category_order_within_macrogroup = c(1L, 2L, 1L, 2L),
  stringsAsFactors = FALSE
)

stopifnot(
  setequal(dictionary$gene_set_id, term2gene$gs_name),
  all(dictionary$tier == "custom"),
  all(dictionary$category_id %in% category_map$category_id),
  all(dictionary$category_display_name ==
    category_map$display_name[match(
      dictionary$category_id, category_map$category_id
    )])
)

print(dictionary)
print(category_map)

## ----save-tables, eval=TRUE---------------------------------------------------
resource_files <- c(
  lisa_dictionary = file.path(resource_dir, "sample_dict.tsv"),
  category_map = file.path(resource_dir, "sample_map.tsv"),
  term2gene = file.path(resource_dir, "sample_t2g.tsv")
)

utils::write.table(
  dictionary, resource_files[["lisa_dictionary"]],
  sep = "\t", quote = FALSE, row.names = FALSE, na = ""
)
utils::write.table(
  category_map, resource_files[["category_map"]],
  sep = "\t", quote = FALSE, row.names = FALSE, na = ""
)
utils::write.table(
  term2gene, resource_files[["term2gene"]],
  sep = "\t", quote = FALSE, row.names = FALSE, na = ""
)

## ----inspect-local-resource-files, eval=TRUE----------------------------------
local_bytes <- data.frame(
  role = names(resource_files),
  artifact = basename(resource_files),
  bytes = unname(file.info(resource_files)$size),
  sha256 = unname(vapply(resource_files, function(path) {
    digest::digest(file = path, algo = "sha256", serialize = FALSE)
  }, character(1)))
)
stopifnot(all(file.exists(resource_files)), all(local_bytes$bytes > 0),
          all(dictionary$gene_set_id %in% term2gene$gs_name),
          all(dictionary$category_id %in% category_map$category_id))
print(local_bytes, row.names = FALSE)

## ----create-manifest, eval=FALSE----------------------------------------------
# reviewer <- trimws(readline("Reviewer name or initials: "))
# review_note <- trimws(readline("What did you check? "))
# stopifnot(nzchar(reviewer), nzchar(review_note))
# 
# reviewed_at <- format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
# approved_origin <- paste0(
#   "Local sample custom-resource review by ", reviewer,
#   " on ", reviewed_at, ": ", review_note
# )
# 
# reviewed_sha256 <- vapply(resource_files, function(path) {
#   digest::digest(file = path, algo = "sha256", serialize = FALSE)
# }, character(1))
# 
# manifest <- data.frame(
#   logical_id = c(
#     "my_lab_sample_dictionary",
#     "my_lab_sample_category_map",
#     "my_lab_sample_term2gene"
#   ),
#   version = rep("1.0.0", 3),
#   species = rep("Homo sapiens", 3),
#   modality = rep("transcriptomic/genomic", 3),
#   schema = c("lisa_dictionary@2", "category_map@1", "term2gene@1"),
#   sha256 = unname(reviewed_sha256),
#   compatibility = rep("lisaR>=0.6.0", 3),
#   approved_origin = rep(approved_origin, 3),
#   artifact = basename(unname(resource_files)),
#   stringsAsFactors = FALSE
# )
# 
# manifest_path <- file.path(resource_dir, "resource_manifest.tsv")
# utils::write.table(
#   manifest, manifest_path,
#   sep = "\t", quote = FALSE, row.names = FALSE, na = ""
# )
# print(manifest)

## ----register-persistent, eval=FALSE------------------------------------------
# manifest <- utils::read.delim(
#   manifest_path, sep = "\t", quote = "", comment.char = "",
#   check.names = FALSE, stringsAsFactors = FALSE,
#   colClasses = "character", na.strings = character()
# )
# 
# installed <- lapply(seq_len(nrow(manifest)), function(i) {
#   row <- manifest[i, , drop = FALSE]
#   install_lisa_resource(
#     source = file.path(resource_dir, row$artifact),
#     logical_id = row$logical_id,
#     version = row$version,
#     species = row$species,
#     modality = row$modality,
#     schema = row$schema,
#     approved_origin = row$approved_origin,
#     expected_sha256 = row$sha256,
#     compatibility = row$compatibility
#   )
# })
# 
# refs <- setNames(
#   paste0(manifest$logical_id, "@", manifest$version),
#   manifest$schema
# )
# 
# checked <- validate_lisa_custom_resources(
#   dictionary_resource = refs[["lisa_dictionary@2"]],
#   category_map_resource = refs[["category_map@1"]],
#   term2gene_resource = refs[["term2gene@1"]],
#   species = "Homo sapiens"
# )
# 
# print(checked$resources[, c("config_key", "resource_id", "schema", "ready")])
# print(as.data.frame(checked$summary, stringsAsFactors = FALSE))
# stopifnot(checked$valid)

## ----select-bundle, eval=FALSE------------------------------------------------
# study <- yaml::read_yaml(file.path(project, "study.yml"))
# study$pipeline$workers <- 1L
# study$pipeline$lisa_dictionary <- NULL
# study$pipeline$dictionary_resource <- refs[["lisa_dictionary@2"]]
# study$pipeline$category_map_resource <- refs[["category_map@1"]]
# study$pipeline$term2gene_resource <- refs[["term2gene@1"]]
# 
# custom_config <- file.path(project, "study-custom.yml")
# yaml::write_yaml(study, custom_config)
# 
# validation <- validate_lisa_config(custom_config, check_files = TRUE)
# print(validation$resources[, c(
#   "config_key", "configured_id", "resource_id", "species",
#   "schema", "ready", "message"
# )])
# stopifnot(validation$execution_ready)

## ----run-custom-study, eval=FALSE---------------------------------------------
# result <- run_lisa(custom_config)
# check <- verify_lisa_run(result$output_dir)
# stopifnot(identical(result$gate, "PASS"), identical(check$gate, "PASS"))
# 
# resolved <- utils::read.delim(
#   file.path(result$output_dir, "config", "resource_resolution.tsv"),
#   sep = "\t", quote = "", comment.char = "", check.names = FALSE
# )
# print(resolved[, c("config_key", "configured_id", "resource_id", "schema")])
# 
# browseURL(file.path(result$output_dir, "report_index.html"))

## ----documentation-session-info, eval=TRUE------------------------------------
sessionInfo()

