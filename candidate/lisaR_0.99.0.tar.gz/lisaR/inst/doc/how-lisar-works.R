## ----open-shiny, eval=FALSE---------------------------------------------------
# library(lisaR)
# explore_lisa_run("path/to/the/saved-run")

## ----packaged-provenance, eval=TRUE-------------------------------------------
system.file(
  "extdata", "dictionaries", "RESOURCE_PROVENANCE.tsv",
  package = "lisaR"
)
system.file(
  "extdata", "dictionaries", "TECHNICAL_REBUILD_PROVENANCE.md",
  package = "lisaR"
)
system.file(
  "extdata", "dictionaries", "RESOURCE_MIGRATION_MANIFEST.tsv",
  package = "lisaR"
)

## ----semantic-lookup, eval=TRUE-----------------------------------------------
catalog_path <- system.file(
  "extdata", "semantic-catalog", "semantic_category_catalog.tsv",
  package = "lisaR", mustWork = TRUE
)
semantic_catalog <- read.delim(
  catalog_path, sep = "\t", quote = "", comment.char = "",
  colClasses = "character", check.names = FALSE
)

head(semantic_catalog[c(
  "universe", "category_id", "category_display_name", "macrogroup_name"
)])

## ----semantic-search, eval=TRUE-----------------------------------------------
query <- "repair|checkpoint"
matches <- grepl(
  query,
  paste(
    semantic_catalog$category_display_name,
    semantic_catalog$category_description
  ),
  ignore.case = TRUE
)
semantic_catalog[matches, c(
  "universe", "category_id", "category_display_name",
  "macrogroup_name", "core_member_gene_sets"
)]

## ----semantic-select, eval=TRUE-----------------------------------------------
chosen <- semantic_catalog[
  semantic_catalog$universe == "GOBP-C2" &
    semantic_catalog$category_id == "DNA_DAMAGE_REPAIR_CHECKPOINTS",
  c("category_display_name", "macrogroup_name", "core_member_gene_sets",
    "example_gene_set_1", "example_gene_set_2", "example_gene_set_3")
]
stopifnot(nrow(chosen) == 1L)
print(chosen, row.names = FALSE)

## ----semantic-distinct-support, eval=TRUE-------------------------------------
semantic_counts <- read.delim(system.file(
  "extdata", "semantic-catalog", "semantic_supercategory_counts.tsv",
  package = "lisaR", mustWork = TRUE
), sep = "\t", check.names = FALSE)
pi3k <- semantic_counts[
  semantic_counts$macrogroup_id == "PI3K_AKT_MTOR",
  c("universe", "macrogroup_id", "core_distinct_gene_sets",
    "core_member_assignments")
]
stopifnot(nrow(pi3k) == 1L,
          pi3k$core_distinct_gene_sets == 59L,
          pi3k$core_member_assignments == 88L)
print(pi3k, row.names = FALSE)

## ----documentation-session-info, eval=TRUE------------------------------------
sessionInfo()

