## ----install-lisar, eval=FALSE------------------------------------------------
# install.packages(c("BiocManager", "remotes"))
# BiocManager::install("fgsea", update = FALSE, ask = FALSE)
# # If needed, install these optional guide-build packages manually:
# install.packages(c("knitr", "rmarkdown"))
# BiocManager::install("edgeR", update = FALSE, ask = FALSE)
# # Confirm that Pandoc is available in your own build session:
# rmarkdown::pandoc_available()
# remotes::install_github(
#   "DBM-OlmedaLab/lisaR",
#   upgrade = "never",
#   build_vignettes = TRUE
# )
# 
# library(lisaR)
# packageVersion("lisaR")

## ----initialise, eval=TRUE----------------------------------------------------
library(lisaR)

root <- tempfile("lisa-offline-")
dir.create(root)
project <- lisa_init_project(file.path(root, "sample"))

## ----configure, eval=TRUE-----------------------------------------------------
study <- yaml::read_yaml(file.path(project, "study.yml"))
study$pipeline$workers <- 1L
study$collections <- list("GOBP-C2")
study$report$category_nes_variants <- list("clean")
study$report$source_data <- FALSE
config <- file.path(project, "run.yml")
yaml::write_yaml(study, config)

## ----validate, eval=TRUE------------------------------------------------------
validation <- validate_lisa_config(config, check_files = TRUE)
validation$execution_ready
stopifnot(validation$execution_ready)

## ----diagnose, eval=TRUE------------------------------------------------------
validation$readiness
validation$inputs
validation$dependencies
validation$resources

## ----plan, eval=TRUE----------------------------------------------------------
plan <- plan_lisa_outputs(config)
plan$summary
plan$products

## ----run, eval=TRUE-----------------------------------------------------------
result <- run_lisa(config)
result$gate

## ----verify, eval=TRUE--------------------------------------------------------
check <- verify_lisa_run(result$output_dir)
check[c("gate", "artifact_type")]
stopifnot(identical(check$gate, "PASS"),
          identical(check$artifact_type, "scientific_run"))

# Read this evaluated run, not the earlier PNG snapshot, for the live numbers.
inference_path <- file.path(result$output_dir, "outputs", "single_de", "response_a",
  "collection_GOBP-C2", "lisa_tables", "response_a_LISA_category_inference.tsv")
inference <- utils::read.delim(inference_path, check.names = FALSE)
snapshot <- utils::read.delim("figures/quick-start-snapshot-inference.tsv",
  check.names = FALSE)
idx <- match(inference$category_id, snapshot$category_id)
stopifnot(!anyNA(idx), nrow(inference) == nrow(snapshot))
inference_display <- data.frame(
  Category = inference$category_display_name,
  Adjusted_P = format(signif(inference$category_p_adjusted, 5),
    scientific = TRUE, trim = TRUE),
  Minimum_d_N = paste0(inference$minimum_enriched_sets, "/", inference$n_sets_total),
  Evaluable_mapped = paste0(inference$n_sets_evaluable, "/", inference$n_sets_total),
  Status = inference$status)
knitr::kable(inference_display, caption = "This evaluated run: rounded adjusted P and supported d/N")
inference_comparison <- data.frame(
  Category = inference$category_display_name,
  same_rounded_P = signif(inference$category_p_adjusted, 5) ==
    signif(snapshot$category_p_adjusted[idx], 5),
  same_supported_count = inference$minimum_enriched_sets == snapshot$minimum_enriched_sets[idx] &
    inference$n_sets_total == snapshot$n_sets_total[idx])
knitr::kable(inference_comparison, caption = "Comparison with the earlier saved figure snapshot")

## ----open, eval=FALSE---------------------------------------------------------
# browseURL(file.path(result$output_dir, "report_index.html"))

## ----cite-lisar, eval=TRUE----------------------------------------------------
citation("lisaR")
packageDescription("lisaR")[
  c("Package", "Version", "Date", "URL", "Author")
]

## ----locate-licence-notices, eval=TRUE----------------------------------------
system.file("COPYING", package = "lisaR")
system.file("THIRD_PARTY_NOTICES.md", package = "lisaR")
system.file(
  "extdata", "dictionaries", "RESOURCE_PROVENANCE.tsv",
  package = "lisaR"
)

## ----documentation-session-info, eval=TRUE------------------------------------
sessionInfo()

