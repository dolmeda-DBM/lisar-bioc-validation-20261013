## ----installation-dependencies, eval=FALSE------------------------------------
# install.packages(c("BiocManager", "remotes"))
# BiocManager::install(
#   c("digest", "fgsea", "fs", "ggplot2", "hommel", "jsonlite", "openxlsx", "readr", "yaml"),
#   update = FALSE,
#   ask = FALSE
# )

## ----install-github, eval=FALSE-----------------------------------------------
# # If needed, install these optional guide-build packages manually:
# install.packages(c("knitr", "rmarkdown"))
# BiocManager::install("edgeR", update = FALSE, ask = FALSE)
# # Confirm that Pandoc is available in your own build session:
# rmarkdown::pandoc_available()
# remotes::install_github(
#   "DBM-OlmedaLab/lisaR",
#   upgrade = "never",
#   build_vignettes = TRUE
# )

## ----confirm-installation, eval=TRUE------------------------------------------
library(lisaR)
packageVersion("lisaR")
find.package("lisaR")
system.file("extdata", "dictionaries", package = "lisaR")
system.file("examples", "quick-start", "study.yml", package = "lisaR")

## ----open-online-guide, eval=FALSE--------------------------------------------
# browseURL("https://olmedalab.org/lisaR/reader/start-with-lisar.html?lang=en")

## ----reference-complete-config, eval=TRUE-------------------------------------
library(lisaR)

cfg <- list(
  pipeline = list(
    schema_version = "1.0.0",
    profile = "transcriptomic/genomic",
    evidence_mode = "full_de",
    output_dir = "results/minimal-study",
    dry_run = TRUE,
    workers = 4L,
    dictionary_resource = "lisa_dictionary_quickstart@1.1.0",
    term2gene_resource = "lisa_quickstart_term2gene@2.1.0",
    category_map_resource = "lisa_quickstart_category_map@1.1.0",
    run_kegg_maps = FALSE,
    run_hallmarks = FALSE,
    sufficiency_action = "ignore_with_reason",
    sufficiency_ignore_reason = "Bundled synthetic sample dataset; the restricted universe is intentional.",
    duplicate_policies = list(
      de_table_duplicate_policy = "error",
      matrix_duplicate_policy = "error",
      mapped_id_collision_policy = "error"
    )
  ),
  report = list(
    mode = "standard",
    category_evidence = TRUE,
    category_nes_variants = c("clean", "percentages", "direction", "dispersion"),
    legacy_gene_products = FALSE,
    evidence_max_sets = 25L,
    evidence_max_genes = 40L,
    formats = list(png = TRUE, svg = FALSE, pdf = FALSE),
    source_data = TRUE,
    recipes = FALSE
  ),
  collections = c("GOBP-C2", "GOMF", "GOCC", "PATHWAYS"),
  single_de = list(
    list(
    analysis_id = "treatment",
    de_path = system.file("extdata", "minimal", "de_A.tsv", package = "lisaR"),
    species = "Homo sapiens",
    symbol_col = "symbol",
    logfc_col = "log2FC",
    padj_col = "padj"),
    list(
    analysis_id = "control",
    de_path = system.file("extdata", "minimal", "de_B.tsv", package = "lisaR"),
    species = "Homo sapiens",
    symbol_col = "symbol",
    logfc_col = "log2FC",
    padj_col = "padj")
  ),
  contrasts = list(list(
    contrast_id = "treatment_vs_control",
    analysis_a = "treatment",
    analysis_b = "control",
    contrast_label = "Treatment versus control"
  ))
)

validation <- validate_lisa_config(cfg, check_files = FALSE)
stopifnot(validation$structural_valid, !validation$execution_ready)
validation$readiness

## ----reference-resolved-config, eval=TRUE-------------------------------------
validation$config$report
validation$configuration_provenance[
  validation$configuration_provenance$field %in% c(
    "report.category_evidence", "report.category_nes_variants",
    "pipeline.gsea_padj_cutoff", "pipeline.cache_mode"
  ),
]

## ----reference-output-choices, eval=TRUE--------------------------------------
clean_only <- cfg
clean_only$report$category_nes_variants <- "clean"
clean_check <- validate_lisa_config(clean_only, check_files = FALSE)
stopifnot(identical(
  unlist(clean_check$config$report$category_nes_variants, use.names = FALSE),
  "clean"
))

dispersion_only <- cfg
dispersion_only$report$category_nes_variants <- "dispersion"
dispersion_check <- validate_lisa_config(dispersion_only, check_files = FALSE)
stopifnot(identical(
  unlist(dispersion_check$config$report$category_nes_variants, use.names = FALSE),
  "dispersion"
))

all_plan <- plan_lisa_outputs(cfg, category_counts = c(`GOBP-C2` = 2L))
clean_plan <- plan_lisa_outputs(clean_only, category_counts = c(`GOBP-C2` = 2L))
all_plan$summary
clean_plan$summary

## ----reference-no-static-figures, eval=TRUE-----------------------------------
no_static <- cfg
no_static$report$formats <- list(png = FALSE, svg = FALSE, pdf = FALSE)
no_static_check <- validate_lisa_config(no_static, check_files = FALSE)
stopifnot(!any(unlist(no_static_check$config$report$formats)))

## ----config-deseq2-object-template, eval=FALSE--------------------------------
# result <- run_lisa_de(
#   dds,
#   output_dir = "results/treated-vs-control",
#   comparison_name = "treated_vs_control",
#   species = "Homo sapiens",
#   symbol_col = "rowname",
#   deseq2_name = "condition_treated_vs_control",
#   universes = c("GOBP-C2", "GOMF", "GOCC", "PATHWAYS")
# )

## ----config-trusted-rds-template, eval=FALSE----------------------------------
# result <- run_lisa_de(
#   "dds.rds",
#   output_dir = "results/treated-vs-control-rds",
#   comparison_name = "treated_vs_control",
#   species = "Homo sapiens",
#   symbol_col = "rowname",
#   trusted_rds = TRUE,
#   deseq2_name = "condition_treated_vs_control",
#   universes = c("GOBP-C2", "GOMF", "GOCC", "PATHWAYS")
# )

## ----obtain-register-msigdb, eval=FALSE---------------------------------------
# library(lisaR)
# 
# msigdb <- prepare_lisa_msigdb_resource(accept_terms = TRUE)
# msigdb[c(
#   "resource_id", "path", "registry_path", "acquired",
#   "source_zip_sha256"
# )]

## ----register-local-msigdb, eval=FALSE----------------------------------------
# source_zip <- file.choose()
# msigdb <- prepare_lisa_msigdb_resource(source_zip = source_zip)

## ----validate-study-resources, eval=TRUE--------------------------------------
resource_project <- lisa_init_project(tempfile("lisa-resources-"))
resource_config <- file.path(resource_project, "study.yml")
validation <- validate_lisa_config(
  resource_config, check_files = TRUE, strict = TRUE
)

validation$resources[, c(
  "config_key", "configured_id", "resource_id", "species",
  "schema", "sha256", "ready", "message"
)]
stopifnot(validation$resources_ready)
stopifnot(validation$execution_ready)

## ----locate-resource-provenance, eval=TRUE------------------------------------
system.file(
  "extdata", "dictionaries", "RESOURCE_BUNDLE_MANIFEST.tsv",
  package = "lisaR"
)
system.file(
  "extdata", "dictionaries", "RESOURCE_PROVENANCE.tsv",
  package = "lisaR"
)
system.file(
  "extdata", "dictionaries", "RESOURCE_MIGRATION_MANIFEST.tsv",
  package = "lisaR"
)

## ----parallel-record-template, eval=FALSE-------------------------------------
# run_dir <- "results/study"
# execution <- read.delim(file.path(run_dir, "parallel_execution.tsv"))
# seeds <- read.delim(file.path(run_dir, "parallel_task_seeds.tsv"))
# execution
# head(seeds)

## ----parallel-retry-template, eval=TRUE---------------------------------------
retry <- yaml::read_yaml(resource_config)
retry$pipeline$workers <- 1L
retry$pipeline$run_id <- "study-retry-01"
retry$pipeline$output_dir <- file.path(resource_project, "study-retry-01")
retry$pipeline$resume <- FALSE

retry_config <- file.path(resource_project, "study-retry-01.yml")
stopifnot(!file.exists(retry_config))
yaml::write_yaml(retry, retry_config)

validation <- lisaR::validate_lisa_config(retry_config, check_files = TRUE)
stopifnot(validation$execution_ready)
plan <- lisaR::plan_lisa_outputs(retry_config)
plan$summary

## ----parallel-verify-template, eval=FALSE-------------------------------------
# check <- lisaR::verify_lisa_run("results/study-retry-01")
# stopifnot(identical(check$gate, "PASS"))

## ----read-bundled-resource-manifest, eval=TRUE--------------------------------
bundle_manifest <- utils::read.delim(system.file(
  "extdata", "dictionaries", "RESOURCE_BUNDLE_MANIFEST.tsv",
  package = "lisaR", mustWork = TRUE
), sep = "\t", check.names = FALSE, colClasses = "character")
print(bundle_manifest)
# Installed packages put inst/ contents directly in the package directory.
artifact_paths <- file.path(find.package("lisaR"), bundle_manifest$artifact)
stopifnot(all(file.exists(artifact_paths)))

## ----documentation-session-info, eval=TRUE------------------------------------
sessionInfo()

