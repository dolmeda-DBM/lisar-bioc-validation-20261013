## ----open-saved-report, eval=TRUE---------------------------------------------
# For your own completed study: run_dir <- "path/to/your/saved-run"
# Extract the shipped complete saved run to a new temporary directory.
fixture_dir <- tempfile("lisa-saved-fixture-")
dir.create(fixture_dir)
utils::untar(system.file("extdata", "p5-tiny-scientific-run.tar.gz",
  package = "lisaR", mustWork = TRUE), exdir = fixture_dir)
run_dir <- file.path(fixture_dir, "p5-tiny-scientific-run", "run")
check <- lisaR::verify_lisa_run(run_dir)
stopifnot(identical(check$gate, "PASS"))
file.exists(file.path(run_dir, "report_index.html"))
# Open manually in an ordinary R session:
# browseURL(file.path(run_dir, "report_index.html"))

## ----open-saved-report-shiny, eval=FALSE--------------------------------------
# lisaR::explore_lisa_run(run_dir)

## ----report-selected-extension, eval=TRUE-------------------------------------
analysis_ids <- read.delim(
  file.path(run_dir, "config", "de_index.tsv")
)$analysis_id
selection <- list(
  selection = list(
    mode = "selected",
    analyses = analysis_ids[[1L]],
    products = c("member_gene_sets", "volcano")
  ),
  report = list(
    mode = "selected",
    formats = list(png = TRUE, svg = FALSE, pdf = FALSE),
    source_data = TRUE,
    recipes = TRUE
  )
)

extension_plan <- lisaR::plan_lisa_extension(run_dir, selection)
extension_plan$expected_files

# Manual rendering option, not executed during the offline build:
# extension <- lisaR::render_lisa_categories(
#   run_dir, selection, "results/study-selected"
# )

## ----report-integrated-full, eval=TRUE----------------------------------------
source_run <- run_dir
analyses <- read.delim(file.path(source_run, "config", "de_index.tsv"))
contrast_file <- file.path(source_run, "config", "contrast_index.tsv")
contrast_text <- readLines(contrast_file, warn = FALSE)
contrasts <- if (any(nzchar(trimws(contrast_text)))) {
  read.delim(contrast_file)
} else {
  data.frame(contrast_id = character())
}
selected_analyses <- analyses$analysis_id
selected_contrasts <- if (nrow(contrasts)) {
  paste(contrasts$contrast_id, collapse = ",")
} else "none"

# Read-only API planning; this tiny fixture has no category-evidence pages.
full_plan <- lisaR::plan_lisa_extension(source_run, list(
  selection = list(mode = "full"),
  report = list(mode = "full")
))
full_plan[c("mode", "expected_files", "selected_categories")]

## ----report-integrated-full-build, eval=FALSE---------------------------------
# builder <- system.file("scripts", "build_selected_LISA_report.R", package = "lisaR")
# # Choose a new persistent output folder for your selected integrated report.
# full_dir <- file.path("results", "study-integrated-full")
# stopifnot(!dir.exists(full_dir))
# dir.create(dirname(full_dir), recursive = TRUE, showWarnings = FALSE)
# args <- c(
#   "--vanilla", shQuote(builder),
#   "--source-dir", shQuote(source_run),
#   "--output-dir", shQuote(full_dir),
#   "--analyses", shQuote(paste(selected_analyses, collapse = ",")),
#   "--contrasts", shQuote(selected_contrasts),
#   "--title", shQuote("Study FULL report"),
#   "--complete-missing", "true"
# )
# rscript <- file.path(R.home("bin"), "Rscript")
# stopifnot(system2(rscript, c(args, "--plan-only", "true")) == 0L)
# # After reviewing that plan:
# stopifnot(system2(rscript, args) == 0L)
# browseURL(file.path(full_dir, "report_index.html"))

## ----install-shiny, eval=FALSE------------------------------------------------
# install.packages(c("shiny", "callr", "ps"))

## ----open-saved-run, eval=FALSE-----------------------------------------------
# library(lisaR)
# 
# run_dir <- "path/to/your/saved-run"
# explore_lisa_run(run_dir)

## ----open-without-browser-launch, eval=FALSE----------------------------------
# explore_lisa_run(run_dir, launch.browser = FALSE)

## ----cancel-figure-api, eval=FALSE--------------------------------------------
# ws <- lisa_explore_open(run_dir)
# request <- lisa_figure_request(
#   unit_type = "single_de",
#   analysis_id = "response_a",
#   collection = "GOBP-C2",
#   category_id = "SYN_SIGNAL",
#   product = "volcano"
# )
# job <- lisa_explore_submit(ws, request, background = TRUE)
# 
# lisa_explore_status(ws)
# lisa_explore_cancel(ws, job$job_id)

## ----troubleshooting-readiness, eval=TRUE-------------------------------------
library(lisaR)
recovery_project <- lisa_init_project(tempfile("lisa-readiness-"))
new_config <- file.path(recovery_project, "study.yml")
validation <- validate_lisa_config(new_config, check_files = TRUE)
validation$readiness
validation$inputs
validation$dependencies
validation$resources

## ----copy-configuration-for-migration, eval=FALSE-----------------------------
# old_config <- file.choose()
# extension <- tools::file_ext(old_config)
# new_config <- file.path(
#   dirname(old_config), paste0("study-schema-1.0.", extension)
# )
# stopifnot(!file.exists(new_config))
# stopifnot(file.copy(old_config, new_config))
# new_config

## ----migrate-configuration, eval=TRUE-----------------------------------------
# Inspect the temporary sample configuration above, not an unreviewed user file.
validation <- validate_lisa_config(new_config, check_files = TRUE, strict = TRUE)
validation$readiness
stopifnot(validation$execution_ready)
plan <- plan_lisa_outputs(new_config)
plan$summary
plan$products

## ----troubleshooting-report-settings, eval=TRUE-------------------------------
validation$config$report
validation$configuration_provenance

## ----troubleshooting-shiny-launch, eval=FALSE---------------------------------
# explore_lisa_run("path/to/your/saved-run", launch.browser = FALSE)

## ----troubleshooting-verify, eval=TRUE----------------------------------------
# For your own study: check <- verify_lisa_run("results/my-study")
check <- lisaR::verify_lisa_run(run_dir)
check$gate
check$findings
stopifnot(identical(check$gate, "PASS"))

## ----inspect-saved-category-figure, eval=TRUE---------------------------------
saved_values <- utils::read.delim(
  file.path("figures", "riaz-category_source.tsv"), sep = "\t",
  check.names = FALSE
)
saved_settings <- jsonlite::read_json(
  file.path("figures", "riaz-category_settings.json"), simplifyVector = TRUE
)
stopifnot(nrow(saved_values) > 0L)
print(utils::head(saved_values))
print(saved_settings)

## ----documentation-session-info, eval=TRUE------------------------------------
# Remove only the temporary extracted fixture after the saved-run examples.
unlink(fixture_dir, recursive = TRUE)
sessionInfo()

