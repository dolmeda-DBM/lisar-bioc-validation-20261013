## ----deseq2-table, eval=TRUE--------------------------------------------------
library(lisaR)

wald <- data.frame(
  gene = c("CXCL9", "GZMB", "MKI67", "TCF7", "IL7R", "CCR7"),
  log2FoldChange = c(1.4, 0.8, -0.7, 0.15, -0.2, NA_real_),
  stat = c(4.2, 2.1, -2.8, 0.4, -0.6, NA_real_),
  pvalue = c(0.00003, 0.036, 0.005, 0.69, 0.55, NA_real_)
)
wald$padj <- p.adjust(wald$pvalue, method = "BH")
wald$padj[5L] <- NA_real_  # Illustrative missing adjusted p-value.

prepared <- prepare_lisa_de_input(
  wald,
  method = "DESeq2",
  columns = list(symbol = "gene"),
  positive_direction = "treated relative to control",
  matrix_scale = "transformed"
)
prepared$data

stopifnot(
  nrow(prepared$data) == nrow(wald),
  identical(prepared$data$rank_value, wald$stat),
  is.na(prepared$data$padj[5L]),
  prepared$row_audit$rank_eligible[5L],
  !prepared$row_audit$rank_eligible[6L]
)

## ----input-audit, eval=TRUE---------------------------------------------------
prepared$column_mapping
prepared$row_audit[c(
  "source_row", "source_id", "retained", "rank_eligible",
  "missing_rank", "missing_padj"
)]
prepared$receipt[c(
  "declared_method", "positive_direction", "rank_source",
  "significance_filter", "producing_software_verified"
)]

## ----limma-table, eval=TRUE---------------------------------------------------
limma_table <- data.frame(
  gene = c("CXCL9", "GZMB", "MKI67", "TCF7"),
  logFC = c(1.3, 0.7, -0.6, 0.1),
  t = c(4.8, 2.5, -3.2, 0.3),
  P.Value = c(0.0001, 0.018, 0.004, 0.77)
)
limma_table$adj.P.Val <- p.adjust(limma_table$P.Value, "BH")
limma_input <- prepare_lisa_de_input(
  limma_table, method = "limma",
  columns = list(symbol = "gene"),
  positive_direction = "treated relative to control"
)
stopifnot(
  identical(limma_input$data$rank_value, limma_table$t),
  nrow(limma_input$data) == nrow(limma_table)
)
limma_input$data

## ----edger-table, eval=TRUE---------------------------------------------------
edger_table <- data.frame(
  symbol = c("CXCL9", "GZMB", "MKI67", "TCF7"),
  logFC = c(1.2, 0.6, -0.5, 0.1),
  F = c(16, 6.25, 9, 0.09),
  PValue = c(0.0008, 0.02, 0.006, 0.77)
)
edger_table$FDR <- p.adjust(edger_table$PValue, "BH")
edger_table$signed_sqrt_F <-
  sign(edger_table$logFC) * sqrt(edger_table[["F"]])

edger_input <- prepare_lisa_de_input(
  edger_table, method = "edgeR",
  columns = list(rank = "signed_sqrt_F"),
  positive_direction = "treated relative to control"
)
stopifnot(
  identical(edger_input$data$rank_value, edger_table$signed_sqrt_F),
  identical(edger_input$data$padj, edger_table$FDR)
)
edger_input$data

## ----duplicate-audit, eval=TRUE-----------------------------------------------
duplicated_source <- rbind(wald, wald[1L, , drop = FALSE])
selected <- prepare_lisa_de_input(
  duplicated_source, "DESeq2",
  columns = list(symbol = "gene"),
  positive_direction = "treated relative to control",
  duplicate_policy = list(
    type = "select", criterion = "max_abs_rank", tie_breaker = "row_number"
  )
)
stopifnot(
  nrow(selected$full_data) == 7L,
  nrow(selected$data) == 6L,
  sum(!selected$row_audit$retained) == 1L
)
selected$row_audit[c("source_row", "source_id", "retained")]

## ----save-prepared, eval=TRUE-------------------------------------------------
input_dir <- tempfile("prepared-de-inputs-")
stopifnot(!file.exists(input_dir))
dir.create(input_dir)

for (part in c(
  "data", "full_data", "receipt", "column_mapping",
  "row_audit", "duplicate_resolution"
)) {
  write.table(
    prepared[[part]], file.path(input_dir, paste0(part, ".tsv")),
    sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
  )
}

## ----own-de, eval=FALSE-------------------------------------------------------
# library(lisaR)
# 
# result <- run_lisa(
#   de = "de_treated_vs_control.tsv",
#   output_dir = "lisa-treated-vs-control",
#   species = "Homo sapiens",
#   method = "DESeq2",
#   positive_direction = "Higher in treated than in control"
# )
# 
# stopifnot(identical(result$gate, "PASS"))
# check <- verify_lisa_run(result$output_dir)
# stopifnot(identical(check$gate, "PASS"))
# browseURL(result$report_index)

## ----prepare-membership, eval=FALSE-------------------------------------------
# library(lisaR)
# 
# msigdb <- prepare_lisa_msigdb_resource(accept_terms = TRUE)

## ----run-one, eval=FALSE------------------------------------------------------
# result <- run_lisa(
#   de                 = "de_treated_vs_control.tsv",
#   output_dir         = "lisa-treated-vs-control",
#   species            = "Homo sapiens",
#   positive_direction = "higher in treated than in control"
# )
# 

## ----verify-one, eval=TRUE----------------------------------------------------
# The evaluated verifier uses the accepted distributed synthetic run.
# For your own analysis, keep result$output_dir from the preceding manual call:
# check <- verify_lisa_run(result$output_dir)
# Extract the shipped complete saved run to a new temporary directory.
fixture_dir <- tempfile("lisa-saved-fixture-")
dir.create(fixture_dir)
utils::untar(system.file("extdata", "p5-tiny-scientific-run.tar.gz",
  package = "lisaR", mustWork = TRUE), exdir = fixture_dir)
saved_run <- file.path(fixture_dir, "p5-tiny-scientific-run", "run")
check <- verify_lisa_run(saved_run)
stopifnot(identical(check$gate, "PASS"))
check[c("gate", "artifact_type")]

## ----open-one, eval=FALSE-----------------------------------------------------
# browseURL(file.path(result$output_dir, "report_index.html"))

## ----run-two, eval=FALSE------------------------------------------------------
# result <- run_lisa(
#   de = list(
#     PRE = "de_pre_vs_control.tsv",
#     ON  = "de_on_vs_control.tsv"
#   ),
#   output_dir = "lisa-pre-on",
#   species    = "Homo sapiens",
#   positive_direction = list(
#     PRE = "higher at baseline than in its control",
#     ON  = "higher on therapy than in its control"
#   ),
#   contrast = c("ON", "PRE"),
#   title    = "Baseline versus on-therapy"
# )
# 
# result$reports[result$reports$page == "contrasts", ]

## ----adjust, eval=FALSE-------------------------------------------------------
# result <- run_lisa(
#   de                 = "de_treated_vs_control.tsv",
#   output_dir         = "lisa-study",
#   species            = "Homo sapiens",
#   positive_direction = "higher in treated than in control",
#   svg                = FALSE,       # PNG only
#   recipes            = FALSE,       # no figure recipes
#   collections        = c("GOBP-C2", "GOMF"),
#   workers            = 4L
# )

## ----advanced-overrides, eval=FALSE-------------------------------------------
# result <- run_lisa(
#   de                 = "de_treated_vs_control.tsv",
#   output_dir         = "lisa-study",
#   species            = "Homo sapiens",
#   positive_direction = "higher in treated than in control",
#   report             = list(evidence_max_sets = 40L),
#   pipeline           = list(run_hallmarks = TRUE)
# )

## ----columns, eval=FALSE------------------------------------------------------
# result <- run_lisa(
#   de                 = "limma_treated_vs_control.tsv",
#   output_dir         = "lisa-limma-study",
#   species            = "Homo sapiens",
#   positive_direction = "higher in treated than in control",
#   method             = "limma",
#   columns            = list(symbol = "gene", rank = "t")
# )

## ----edger, eval=TRUE---------------------------------------------------------
set.seed(1729)
group <- factor(rep(c("control", "treated"), each = 3),
                levels = c("control", "treated"))
baseline <- seq(40, 240, length.out = 60)
effects <- rep(c(2, 0.5, 1), length.out = length(baseline))
means <- vapply(group, function(g)
  baseline * if (g == "treated") effects else 1, numeric(length(baseline)))
counts <- matrix(stats::rnbinom(length(means), mu = as.vector(means), size = 8),
  nrow = length(baseline),
  dimnames = list(paste0("GENE", seq_along(baseline)),
                  paste0("sample", seq_along(group))))
dge <- edgeR::calcNormFactors(edgeR::DGEList(counts = counts, group = group))
design <- stats::model.matrix(~ group)
# A fixed dispersion is declared for this synthetic illustration only.
fit <- edgeR::glmFit(dge, design = design, dispersion = 0.1)
x <- edgeR::glmLRT(fit, coef = "grouptreated") # exactly one df: treated-control
tt <- edgeR::topTags(x, n = Inf, sort.by = "none", adjust.method = "BH")
original <- tt$table
# Choose signed logFC itself as an effect-size ranking. This is not sign(LR),
# nor a signed multi-df F statistic. Positive values mean higher in treated.
tt$table$signed_rank <- tt$table$logFC
prepared <- prepare_lisa_de_input(tt,
  columns = list(rank = "signed_rank"),
  positive_direction = "higher in treated than control")
stopifnot(identical(tt$table[, names(original), drop = FALSE], original),
  identical(rownames(prepared$full_data), rownames(original)),
  identical(prepared$full_data$pvalue, original$PValue),
  identical(prepared$full_data$padj, original$FDR),
  nrow(prepared$full_data) == nrow(original))


## ----edger-analysis, eval=FALSE-----------------------------------------------
# result <- run_lisa(
#   de                 = tt,
#   output_dir         = "lisa-edger-study",
#   species            = "Homo sapiens",
#   positive_direction = "higher in treated than control",
#   columns            = list(rank = "signed_rank")
# )

## ----config-route, eval=TRUE--------------------------------------------------
sample_project <- lisa_init_project(tempfile("lisa-input-config-"))
sample_config <- file.path(sample_project, "study.yml")
validation <- validate_lisa_config(sample_config, check_files = TRUE)
validation$readiness
stopifnot(validation$execution_ready)
plan <- plan_lisa_outputs(sample_config)
plan$summary
# To execute your own reviewed configuration manually:
# result <- run_lisa("study.yml")

## ----documentation-session-info, eval=TRUE------------------------------------
# Remove only the temporary extracted fixture after the saved-run examples.
unlink(fixture_dir, recursive = TRUE)
sessionInfo()

