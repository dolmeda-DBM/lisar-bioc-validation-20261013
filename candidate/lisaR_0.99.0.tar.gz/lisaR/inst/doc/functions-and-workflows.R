## ----reference-prepare-input, eval=TRUE---------------------------------------
library(lisaR)
source_de <- data.frame(
  gene = c("GENE_A", "GENE_B", "GENE_C", "GENE_D"),
  log2FoldChange = c(1, -0.5, 0.1, NA_real_),
  stat = c(3, -1, 0.2, NA_real_),
  pvalue = c(0.001, 0.3, 0.8, NA_real_),
  padj = c(0.01, 0.6, 0.95, NA_real_)
)
prepared <- prepare_lisa_de_input(
  source_de, method = "DESeq2",
  columns = list(symbol = "gene"),
  positive_direction = "Treated relative to control"
)
stopifnot(nrow(prepared$data) == nrow(source_de))
prepared$data
prepared$row_audit[, c("source_row", "rank_eligible")]

## ----reference-api-template-1, eval=TRUE--------------------------------------
root <- tempfile("lisa-functions-")
dir.create(root)
project <- lisa_init_project(file.path(root, "sample"))
config <- file.path(project, "study.yml")

## ----reference-api-template-2, eval=TRUE--------------------------------------
validation <- validate_lisa_config(
  config,
  check_files = TRUE,
  strict = TRUE
)

## ----reference-api-template-3, eval=TRUE--------------------------------------
# This evaluated example reuses reviewed bundled synthetic bytes.
# The local cache is temporary; it does not change your ordinary registry.
resource_manifest <- utils::read.delim(system.file(
  "extdata", "dictionaries", "RESOURCE_BUNDLE_MANIFEST.tsv",
  package = "lisaR", mustWork = TRUE), colClasses = "character")
row <- resource_manifest[resource_manifest$logical_id == "lisa_dictionary_quickstart" &
  resource_manifest$version == "1.1.0", , drop = FALSE]
stopifnot(nrow(row) == 1L)
dictionary_path <- file.path(find.package("lisaR"), row$artifact)
reviewed_dictionary_sha256 <- row$sha256
resource_request <- list(
  source = dictionary_path,
  logical_id = "lab_dictionary",
  version = "1.0.0",
  species = "Homo sapiens",
  modality = "transcriptomic/genomic",
  schema = "lisa_dictionary@2",
  approved_origin = "Reviewed distributed lisaR synthetic dictionary@1.1.0",
  expected_sha256 = reviewed_dictionary_sha256,
  cache_root = tempfile("lisa-documentation-cache-")
)
installed <- do.call(install_lisa_resource, resource_request)
installed$resource_id
stopifnot(file.exists(installed$path))

## ----reference-api-template-example-bundle, eval=FALSE------------------------
# bundle <- install_lisa_example_bundle(
#   example = "riaz-gse91061",
#   destination = "riaz-gse91061-bundle"
# )
# bundle$next_command

## ----reference-api-template-msigdb, eval=FALSE--------------------------------
# term2gene <- prepare_lisa_msigdb_resource(
#   source_zip = "msigdb.2026.1.zip"
# )
# term2gene$resource_id

## ----reference-api-template-4, eval=TRUE--------------------------------------
# Validate the already distributed coherent synthetic bundle.
# After your own persistent registration use lab_dictionary@1.0.0,
# lab_category_map@1.0.0 and lab_term2gene@1.0.0, as in the custom guide.
checked <- validate_lisa_custom_resources(
  dictionary_resource = "lisa_dictionary_quickstart@1.1.0",
  category_map_resource = "lisa_quickstart_category_map@1.1.0",
  term2gene_resource = "lisa_quickstart_term2gene@2.1.0",
  species = "Homo sapiens"
)
stopifnot(checked$valid)
checked$resources

## ----reference-api-template-5, eval=FALSE-------------------------------------
# result <- run_lisa(config)

## ----reference-api-template-6, eval=TRUE--------------------------------------
plan <- plan_lisa_outputs(config)
plan$summary
plan$products

## ----reference-api-template-7, eval=FALSE-------------------------------------
# run_lisa_de(
#   input,
#   output_dir,
#   comparison_name = NULL,
#   species = "Homo sapiens",
#   symbol_col = NULL,
#   rank_col = NULL,
#   logfc_col = NULL,
#   pvalue_col = NULL,
#   padj_col = NULL,
#   universes = c("GOBP-C2", "GOMF", "GOCC", "PATHWAYS"),
#   lisa_dictionary = "core",
#   term2gene_path = NULL,
#   make_heatmaps = FALSE,
#   ...,
#   trusted_rds = FALSE,
#   rds_max_bytes = 512 * 1024^2,
#   limma_coef = NULL,
#   limma_adjust_method = NULL,
#   results_location = NULL,
#   method = NULL,
#   rank_direction = "same_as_effect"
# )

## ----reference-api-template-8, eval=FALSE-------------------------------------
# run_lisa_de(
#   input = dds,
#   output_dir = "results/treated-vs-control",
#   comparison_name = "treated_vs_control",
#   species = "Homo sapiens",
#   symbol_col = "rowname",
#   universes = c("GOBP-C2", "GOMF", "GOCC", "PATHWAYS"),
#   deseq2_name = "condition_treated_vs_control"
# )

## ----reference-api-template-9, eval=FALSE-------------------------------------
# run_lisa_contrast(
#   contrast_a,
#   contrast_b,
#   output_dir,
#   comparison_name = NULL,
#   contrast_a_label = "Contrast A",
#   contrast_b_label = "Contrast B",
#   universes = c("GOBP-C2", "GOMF", "GOCC", "PATHWAYS"),
#   ...
# )

## ----reference-api-template-10, eval=TRUE-------------------------------------
# Extract the shipped complete saved run to a new temporary directory.
fixture_dir <- tempfile("lisa-saved-fixture-")
dir.create(fixture_dir)
utils::untar(system.file("extdata", "p5-tiny-scientific-run.tar.gz",
  package = "lisaR", mustWork = TRUE), exdir = fixture_dir)
saved_run <- file.path(fixture_dir, "p5-tiny-scientific-run", "run")
check <- verify_lisa_run(saved_run)
stopifnot(identical(check$gate, "PASS"))
selection <- list(
  analyses = "response_a",
  categories = "SYN_SIGNAL",
  products = c("gene_cards", "volcano")
)
plan <- plan_lisa_extension(saved_run, selection)
plan[c("mode", "expected_files", "selected_categories")]

## ----reference-api-template-11, eval=FALSE------------------------------------
# rendered <- render_lisa_categories(
#   "results/study",
#   selection,
#   output_dir = "results/study-selected"
# )

## ----reference-api-template-12, eval=TRUE-------------------------------------
check <- verify_lisa_run(saved_run)
check$gate
check$findings
stopifnot(identical(check$gate, "PASS"))

## ----reference-explore-saved-run, eval=FALSE----------------------------------
# explore_lisa_run("results/example")

## ----workflow-single-request, eval=TRUE---------------------------------------
request <- lisaR::lisa_figure_request(
  unit_type = "single_de", analysis_id = "response_a",
  collection = "GOBP-C2", category_id = "SYN_SIGNAL", product = "volcano"
)
request_id <- lisaR::lisa_request_id(request)
request_id

## ----workflow-inspect-saved-run, eval=TRUE------------------------------------
ws <- lisa_explore_open(saved_run,
  extension_root = tempfile("lisa-documentation-exploration-"))
catalog <- lisa_explore_catalog(ws)
head(catalog)
table(lisa_explore_status(ws)$state)
request_plan <- lisa_explore_plan(ws, request)
request_plan

## ----workflow-submit-one-figure, eval=FALSE-----------------------------------
# submission <- lisa_explore_submit(ws, request, background = FALSE)
# submission
# jobs <- lisa_explore_poll(ws, dispatch = FALSE)
# jobs
# available <- lisa_explore_artifacts(ws, request)
# available

## ----workflow-export-available, eval=TRUE-------------------------------------
destination <- file.path(ws$root, "exports", "bundle-001")
# This is an export of currently saved evidence, not a generation request.
# With no submitted job, unavailable extra figures remain unavailable.
bundle <- lisa_explore_export(ws, destination, format = "dir")
bundle

## ----reference-pump-explicit-queue, eval=FALSE--------------------------------
# # ws is an existing exploration workspace; any request was submitted earlier.
# dispatched_job <- lisa_explore_pump(ws, lock_timeout_seconds = 0)

## ----reference-execute-queued-job, eval=FALSE---------------------------------
# # For an advanced worker integration, not a normal browsing action:
# final_job <- lisa_explore_execute_job(ws$root, job_id)

## ----documentation-session-info, eval=TRUE------------------------------------
# Remove only the temporary extracted fixture after the saved-run examples.
unlink(fixture_dir, recursive = TRUE)
sessionInfo()

